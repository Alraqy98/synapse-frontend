// src/modules/summaries/GenerateSummaryModal.jsx
import React, { useState, useEffect } from "react";
import { apiSummaries } from "./apiSummaries";
import { getLibraryItems, getItemById, prepareFile } from "../Library/apiLibrary";
import { ChevronDown, Check } from "lucide-react";
import SummaryFailurePopup from "../../components/SummaryFailurePopup";
import "../../styles/GenerationModal.css";

const API_URL = import.meta.env.VITE_API_URL;

// Helper to get auth token
function getSupabaseToken() {
    try {
        const key = Object.keys(localStorage).find((k) =>
            k.includes("auth-token")
        );
        if (!key) return null;
        const parsed = JSON.parse(localStorage.getItem(key));
        return parsed?.access_token || localStorage.getItem("access_token");
    } catch {
        return localStorage.getItem("access_token");
    }
}

// Premium Dropdown Component (reused from MCQ modal)
function PremiumDropdown({ label, value, setValue, options }) {
    const [open, setOpen] = useState(false);
    const selected = options.find((o) => o.value === value) || options[0];

    return (
        <div className="w-full">
            <label className="text-sm text-muted">{label}</label>

            <div className="relative mt-1">
                <div
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 cursor-pointer flex justify-between items-center hover:border-teal transition"
                    onClick={() => setOpen(!open)}
                >
                    {selected.label}
                    <ChevronDown size={16} className="opacity-60" />
                </div>

                {open && (
                    <div className="absolute left-0 right-0 mt-2 bg-void border border-white/10 rounded-xl shadow-xl z-50 overflow-hidden">
                        {options.map((opt) => {
                            const isSelected = opt.value === value;

                            return (
                                <div
                                    key={opt.value}
                                    className={`px-4 py-3 cursor-pointer hover:bg-white/10 ${
                                        isSelected ? "bg-teal/10" : ""
                                    }`}
                                    onClick={() => {
                                        setValue(opt.value);
                                        setOpen(false);
                                    }}
                                >
                                    <div className="flex items-center gap-2">
                                        {isSelected && (
                                            <Check size={14} className="text-teal" />
                                        )}
                                        <div className="font-medium">{opt.label}</div>
                                    </div>

                                    {opt.desc && (
                                        <div className="text-xs text-muted ml-5 mt-1">
                                            {opt.desc}
                                        </div>
                                    )}
                                </div>
                            );
                        })}
                    </div>
                )}
            </div>
        </div>
    );
}

const looksLikeUuid = (str) =>
    typeof str === "string" &&
    /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(str);

export default function GenerateSummaryModal({
    open,
    onClose,
    onCreated,
    presetFileId = null,
}) {
    if (!open) return null;

    const [title, setTitle] = useState("");
    const [academicStage, setAcademicStage] = useState("4th_year");
    const [specialty, setSpecialty] = useState("");
    const [goal, setGoal] = useState("exam");
    const [instruction, setInstruction] = useState("");

    const [tree, setTree] = useState([]);
    const [expanded, setExpanded] = useState({});
    const [selectedFileId, setSelectedFileId] = useState(presetFileId || null);
    const [selectedFileName, setSelectedFileName] = useState(null);
    const [selectedFile, setSelectedFile] = useState(null);

    const [loadingTree, setLoadingTree] = useState(false);
    const [submitting, setSubmitting] = useState(false);
    const [errorMessage, setErrorMessage] = useState(null);
    const [failurePopup, setFailurePopup] = useState({ isOpen: false, isProcessing: false });

    // Load library tree
    useEffect(() => {
        if (!open) return;
        if (presetFileId) {
            // If presetFileId, find the file name for auto-title and fetch file metadata
            (async () => {
                try {
                    const file = await getItemById(presetFileId);
                    if (file) {
                        setSelectedFile(file);
                        setSelectedFileName(file.title);
                        if (!title.trim()) {
                            setTitle(`${file.title} – Summary`);
                        }
                    }
                } catch (err) {
                    console.error("Failed to load file:", err);
                    // Fallback to searching in tree
                    try {
                        const root = await getLibraryItems("All", null);
                        const findFile = (items) => {
                            for (const item of items) {
                                if (item.id === presetFileId && item.kind === "file") {
                                    return item.title;
                                }
                                if (item.children) {
                                    const found = findFile(item.children);
                                    if (found) return found;
                                }
                            }
                            return null;
                        };
                        const fileName = findFile(root);
                        if (fileName) {
                            setSelectedFileName(fileName);
                            if (!title.trim()) {
                                setTitle(`${fileName} – Summary`);
                            }
                        }
                    } catch (err2) {
                        console.error("Failed to load file name:", err2);
                    }
                }
            })();
            return;
        }

        (async () => {
            setLoadingTree(true);
            try {
                const root = await getLibraryItems("All", null);
                const normalized = root.map((n) => ({
                    ...n,
                    children: n.children || [],
                }));
                setTree(normalized);
            } catch (err) {
                console.error("Summary Modal: failed loading library:", err);
            }
            setLoadingTree(false);
        })();
    }, [open, presetFileId]);

    async function loadChildren(folderId) {
        const items = await getLibraryItems("All", folderId);
        return items.map((c) => ({
            ...c,
            children: c.children || [],
        }));
    }

    function updateNodeRecursive(nodes, id, children) {
        return nodes.map((n) => {
            if (n.id === id) {
                return { ...n, children };
            }
            if (n.children?.length) {
                return {
                    ...n,
                    children: updateNodeRecursive(n.children, id, children),
                };
            }
            return n;
        });
    }

    async function toggleFolder(folder) {
        const id = folder.id;

        if (expanded[id]) {
            setExpanded((prev) => ({ ...prev, [id]: false }));
            return;
        }

        const children = await loadChildren(id);
        setTree((prev) => updateNodeRecursive(prev, id, children));
        setExpanded((prev) => ({ ...prev, [id]: true }));
    }

    async function selectFile(fileId, fileName) {
        // Single file selection - deselect previous if selecting new
        setSelectedFileId(fileId);
        setSelectedFileName(fileName);
        setErrorMessage(null);
        // Auto-generate title if empty
        if (!title.trim()) {
            setTitle(`${fileName} – Summary`);
        }
        // Fetch file metadata
        try {
            const file = await getItemById(fileId);
            setSelectedFile(file);
        } catch (err) {
            console.error("Failed to fetch file:", err);
        }
    }

    function renderNode(node, depth = 0) {
        const pad = { paddingLeft: `${depth * 16}px` };

        if (node.kind === "folder") {
            const isOpen = expanded[node.id];

            return (
                <div key={node.id}>
                    <div
                        className="flex items-center gap-2 py-1 cursor-pointer hover:text-teal"
                        style={pad}
                    >
                        <span onClick={() => toggleFolder(node)}>
                            {isOpen ? "📂" : "📁"}
                        </span>
                        <span onClick={() => toggleFolder(node)}>{node.title}</span>
                    </div>

                    {isOpen &&
                        node.children.map((c) => renderNode(c, depth + 1))}
                </div>
            );
        }

        if (node.kind === "file") {
            const isSelected = selectedFileId === node.id;

            return (
                <div key={node.id} className="flex items-center gap-2 py-1" style={pad}>
                    <input
                        type="radio"
                        name="summary-file-select"
                        checked={isSelected}
                        onChange={() => {
                            selectFile(node.id, node.title);
                            setSelectedFile(node);
                        }}
                    />
                    <span>📄 {node.title}</span>
                </div>
            );
        }

        return null;
    }


    async function handleSubmit() {
        if (!title.trim()) {
            return alert("Enter summary title.");
        }
        if (!selectedFileId) {
            return alert("Please select a file.");
        }

        if (!looksLikeUuid(selectedFileId)) {
            console.warn("Invalid file ID:", selectedFileId);
            setErrorMessage("Invalid file selected.");
            return;
        }

        const payload = {
            title: title.trim(),
            fileId: selectedFileId,
            academic_stage: academicStage || null,
            specialty: specialty || null,
            goal: goal || null,
            instruction: instruction.trim() || null,
        };

        try {
            setSubmitting(true);
            setErrorMessage(null);

            // Trigger rendering (non-blocking, backend handles asynchronously)
            try {
                await prepareFile(selectedFileId);
            } catch (prepareErr) {
                // Continue even if prepare-file fails - generator will handle it
                console.warn("Prepare file warning:", prepareErr);
            }

            // Call POST /ai/summaries/generate (atomic operation)
            const result = await apiSummaries.generateSummary(payload);
            
            if (result?.jobId) {
                onCreated({ jobId: result.jobId, title: title.trim(), file_name: selectedFileName });
                onClose();
            } else {
                throw new Error("Invalid response from server");
            }
        } catch (err) {
            console.error("Summary generation error:", err);
            
            // Fail loudly if route is wrong
            if (err.code === "ROUTE_NOT_FOUND" || err.status === 404) {
                const errorMsg = err.message || "Summary generation endpoint not found. Please check backend configuration.";
                setErrorMessage(errorMsg);
                // Show failure popup for route errors
                setFailurePopup({ isOpen: true, isProcessing: false });
            } else if (err.code === "FILE_NOT_READY" || err.message?.includes("Preparing content")) {
                // File is still processing - show "Still preparing" popup
                setFailurePopup({ isOpen: true, isProcessing: true });
                setErrorMessage(err.message || "Preparing content. This usually takes a few seconds.");
            } else {
                // Actual failure - show failure popup
                const errorMsg = err.response?.data?.error || err.message || "Summary generation failed.";
                setErrorMessage(errorMsg);
                setFailurePopup({ isOpen: true, isProcessing: false });
            }
            setSubmitting(false);
        }
    }

    // Reset state when modal opens/closes
    useEffect(() => {
        if (!open) {
            setErrorMessage(null);
        }
    }, [open]);

    // Unified close handler
    const handleClose = () => {
        onClose();
    };

    // ESC key handler
    useEffect(() => {
        const handleEsc = (e) => {
            if (e.key === "Escape") {
                handleClose();
            }
        };
        window.addEventListener("keydown", handleEsc);
        return () => window.removeEventListener("keydown", handleEsc);
    }, []);

    return (
        <div 
            className="synapse-gen-modal synapse-gen-modal-backdrop"
            onClick={handleClose}
        >
            <div
                className="synapse-gen-modal-box"
                onClick={(e) => e.stopPropagation()}
            >
                <div className="synapse-gen-modal-header">
                    <h2 className="synapse-gen-modal-title">Generate Summary</h2>
                    <p className="synapse-gen-modal-subtitle">
                        {presetFileId && (selectedFileName || selectedFile?.title)
                            ? `Generating from: ${selectedFileName || selectedFile?.title}`
                            : "Select source file below."}
                    </p>
                    <button
                        type="button"
                        className="synapse-gen-modal-close"
                        onClick={handleClose}
                        aria-label="Close"
                    >
                        ×
                    </button>
                </div>

                <div className="synapse-gen-modal-field">
                    <label className="synapse-gen-modal-label">Title</label>
                    <input
                        className="synapse-gen-modal-input"
                        placeholder="e.g., Cardiology Block Summary"
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                    />
                </div>

                <div className="synapse-gen-modal-grid-3">
                    <PremiumDropdown
                        label="Academic Stage"
                        value={academicStage}
                        setValue={setAcademicStage}
                        options={[
                            { value: "1st_year", label: "1st Year" },
                            { value: "2nd_year", label: "2nd Year" },
                            { value: "3rd_year", label: "3rd Year" },
                            { value: "4th_year", label: "4th Year" },
                            { value: "5th_year", label: "5th Year" },
                            { value: "6th_year", label: "6th Year" },
                            { value: "internship", label: "Internship" },
                            { value: "residency", label: "Residency" },
                        ]}
                    />
                    <PremiumDropdown
                        label="Specialty"
                        value={specialty}
                        setValue={setSpecialty}
                        options={[
                            { value: "", label: "None" },
                            { value: "general_surgery", label: "General Surgery" },
                            { value: "internal_medicine", label: "Internal Medicine" },
                            { value: "pediatrics", label: "Pediatrics" },
                            { value: "obstetrics_gynecology", label: "OB/GYN" },
                            { value: "psychiatry", label: "Psychiatry" },
                            { value: "emergency", label: "Emergency Medicine" },
                            { value: "radiology", label: "Radiology" },
                            { value: "pathology", label: "Pathology" },
                        ]}
                    />
                    <PremiumDropdown
                        label="Goal"
                        value={goal}
                        setValue={setGoal}
                        options={[
                            { value: "exam", label: "Exam" },
                            { value: "understanding", label: "Understanding" },
                            { value: "revision", label: "Revision" },
                        ]}
                    />
                </div>

                <div className="synapse-gen-modal-field">
                    <label className="synapse-gen-modal-label">Optional Instruction (max 200 chars)</label>
                    <textarea
                        className="synapse-gen-modal-input"
                        placeholder="e.g., Focus on high-yield exam points and common traps"
                        value={instruction}
                        onChange={(e) => {
                            if (e.target.value.length <= 200) setInstruction(e.target.value);
                        }}
                        rows={3}
                        maxLength={200}
                    />
                    <div className="text-xs mt-1 text-right" style={{ color: "var(--gen-text-muted)" }}>
                        {instruction.length}/200
                    </div>
                </div>

                {!presetFileId ? (
                    <>
                        <label className="synapse-gen-modal-label">Source File</label>
                        <div className="synapse-gen-file-list mt-1">
                            {loadingTree ? (
                                <div style={{ color: "var(--gen-text-muted)", fontSize: 13 }}>Loading files…</div>
                            ) : tree.length === 0 ? (
                                <div style={{ color: "var(--gen-text-muted)", fontSize: 13, opacity: 0.8 }}>No files found in your library.</div>
                            ) : (
                                tree.map((n) => renderNode(n))
                            )}
                        </div>
                        {selectedFileId && (
                            <p className="text-xs mt-1" style={{ color: "var(--gen-text-muted)" }}>Selected: {selectedFileName}</p>
                        )}
                    </>
                ) : (
                    <div className="synapse-gen-message mt-2">
                        <p style={{ margin: 0 }}>File: <strong style={{ color: "var(--gen-text-primary)" }}>{selectedFileName || "Loading..."}</strong></p>
                        <p className="text-xs mt-1" style={{ margin: 0, color: "var(--gen-text-muted)" }}>File is locked for this summary.</p>
                    </div>
                )}

                {errorMessage && (
                    <div className="synapse-gen-message mt-2">
                        <p style={{ margin: 0 }}>{errorMessage}</p>
                    </div>
                )}

                {submitting && (
                    <div className="synapse-gen-message mt-2">
                        <p style={{ margin: 0 }}>Generating summary…</p>
                    </div>
                )}

                <div className="synapse-gen-modal-footer">
                    <button type="button" className="synapse-gen-modal-btn-cancel" onClick={handleClose}>
                        Cancel
                    </button>
                    <button
                        type="button"
                        className="synapse-gen-modal-btn-primary"
                        disabled={submitting || !title.trim() || !selectedFileId}
                        onClick={handleSubmit}
                    >
                        {submitting ? "Generating…" : "Generate"}
                    </button>
                </div>
            </div>

            {/* Summary Failure Popup */}
            <SummaryFailurePopup
                isOpen={failurePopup.isOpen}
                onClose={() => {
                    setFailurePopup({ isOpen: false, isProcessing: false });
                    setErrorMessage(null);
                }}
                onRetry={() => {
                    setFailurePopup({ isOpen: false, isProcessing: false });
                    setErrorMessage(null);
                    // User can retry by clicking Generate again
                }}
                isProcessing={failurePopup.isProcessing}
            />
        </div>
    );
}

