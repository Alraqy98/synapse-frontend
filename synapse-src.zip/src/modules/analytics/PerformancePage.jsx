import { useState } from "react";
import { useNavigate } from "react-router-dom";
import useLearningState from "./hooks/useLearningState";
import useLearningHistory from "./hooks/useLearningHistory";

// ─── SIMPLE TOOLTIP COMPONENT ──────────────────────────────────────────────
function InfoTooltip({ content }) {
  const [show, setShow] = useState(false);
  return (
    <span className="relative inline-block">
      <span 
        className="inline-flex items-center justify-center w-3.5 h-3.5 rounded-full border border-white/20 text-white/30 hover:text-white/60 hover:border-white/40 cursor-help transition-colors"
        style={{ fontSize: "9px", lineHeight: "1" }}
        onMouseEnter={() => setShow(true)}
        onMouseLeave={() => setShow(false)}
      >
        ⓘ
      </span>
      {show && (
        <div className="absolute z-50 bottom-full left-1/2 -translate-x-1/2 mb-2 w-64 px-3 py-2 bg-[#1a1d24] border border-white/20 rounded-lg shadow-2xl text-xs text-white/70 leading-relaxed">
          {content}
          <div className="absolute top-full left-1/2 -translate-x-1/2 -mt-px w-0 h-0 border-l-4 border-r-4 border-t-4 border-l-transparent border-r-transparent border-t-white/20" />
        </div>
      )}
    </span>
  );
}

// ─── RELATIVE TIME HELPER ──────────────────────────────────────────────────
function getRelativeTime(timestamp) {
  if (!timestamp) return "recently";
  const now = Date.now();
  const past = new Date(timestamp).getTime();
  const diffMs = now - past;
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);

  if (diffMins < 1) return "just now";
  if (diffMins === 1) return "1 minute ago";
  if (diffMins < 60) return `${diffMins} minutes ago`;
  if (diffHours === 1) return "1 hour ago";
  if (diffHours < 24) return `${diffHours} hours ago`;
  if (diffDays === 1) return "1 day ago";
  return `${diffDays} days ago`;
}

// ─── STATE CONFIG ──────────────────────────────────────────────────────────
const STATE_CONFIG = {
  DECLINING: {
    label: "DECLINING",
    color: "#E55A4E",
    colorDim: "#7A2D28",
    colorBg: "rgba(229,90,78,0.08)",
    colorBorder: "rgba(229,90,78,0.25)",
    dot: "#E55A4E",
  },
  STABLE: {
    label: "STABLE",
    color: "#C4A84F",
    colorDim: "#7A6520",
    colorBg: "rgba(196,168,79,0.08)",
    colorBorder: "rgba(196,168,79,0.25)",
    dot: "#C4A84F",
  },
  IMPROVING: {
    label: "IMPROVING",
    color: "#4E9E7A",
    colorDim: "#2A5C47",
    colorBg: "rgba(78,158,122,0.08)",
    colorBorder: "rgba(78,158,122,0.25)",
    dot: "#4E9E7A",
  },
};

// ─── MICROCOPY ENGINE ──────────────────────────────────────────────────────
function getMicrocopy(data) {
  const overall_state = data.overall?.state || data.overall_state;
  
  // Safely extract momentum (can be object with .dot, number, or null)
  const rawMomentum = data.overall?.momentum || data.momentum;
  const momentum = typeof rawMomentum === 'object' && rawMomentum !== null 
    ? (rawMomentum.dot ?? 0) 
    : (rawMomentum ?? 0);
  
  const chronic_risk = data.chronic_risk;
  const days_in_state = data.days_in_state || 0;
  const transition_history = data.transition || data.transition_history || [];

  if (overall_state === "DECLINING" && momentum <= -30) {
    return {
      headline: "Accelerating decline detected.",
      subline: `Accuracy dropped ${Math.abs(momentum)}% in ${days_in_state} days across multiple concepts. This is a pattern, not noise.`,
      urgency: "URGENT",
      cta: "Stop repeating. Fix the gap.",
    };
  }
  if (overall_state === "DECLINING") {
    return {
      headline: "Performance is declining.",
      subline: `${days_in_state} days on a downward trajectory. More practice on the same material will not reverse this.`,
      urgency: "HIGH",
      cta: "Change your approach.",
    };
  }
  if (overall_state === "STABLE" && chronic_risk) {
    return {
      headline: "Chronic risk pattern.",
      subline: `This concept cluster has regressed ${transition_history.filter(t => t.state === "DECLINING").length} times. Repetition is not building retention.`,
      urgency: "MODERATE",
      cta: "Structured review required.",
    };
  }
  if (overall_state === "STABLE" && momentum <= 2) {
    return {
      headline: "Stable, but not improving.",
      subline: `${days_in_state} days without meaningful gain. Volume is there. Depth is not.`,
      urgency: "WATCH",
      cta: "Adjust study method.",
    };
  }
  return {
    headline: "Performance is improving.",
    subline: `Momentum: +${momentum}%. Keep the current approach.`,
    urgency: "LOW",
    cta: null,
  };
}

// ─── CHART DATA SANITIZER ───────────────────────────────────────────────────
/** Extract numeric y-values from session data, filter null/undefined/NaN. Returns empty array if all invalid. */
function sanitizeChartData(data) {
  if (!Array.isArray(data)) return [];
  const values = data
    .map((item) => {
      const v = typeof item === "object" && item !== null ? item.accuracy : item;
      return typeof v === "number" ? v : null;
    })
    .filter((v) => v != null && !Number.isNaN(v));
  return values;
}

// ─── MINI SPARKLINE ────────────────────────────────────────────────────────
function Sparkline({ data, color, height = 36 }) {
  const values = sanitizeChartData(data);
  if (values.length === 0) {
    return null;
  }

  const w = 120, h = height;
  const min = Math.min(...values);
  const max = Math.max(...values);
  const range = max - min || 1;
  const pts = values.map((v, i) => {
    const x = values.length === 1 ? w / 2 : (i / (values.length - 1)) * w;
    const y = h - ((v - min) / range) * (h - 4) - 2;
    return `${x},${y}`;
  });
  return (
    <svg width={w} height={h} className="block">
      <polyline 
        points={pts.join(" ")} 
        fill="none" 
        stroke={color} 
        strokeWidth="1.5" 
        strokeLinejoin="round" 
        strokeLinecap="round" 
        opacity="0.9" 
      />
      <circle 
        cx={pts[pts.length - 1].split(",")[0]} 
        cy={pts[pts.length - 1].split(",")[1]} 
        r="2.5" 
        fill={color} 
      />
    </svg>
  );
}

// ─── ACCURACY BAR ─────────────────────────────────────────────────────────
function AccuracyBar({ value, trend }) {
  const color = value >= 75 ? "#4E9E7A" : value >= 60 ? "#C4A84F" : "#E55A4E";
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-[3px] bg-white/[0.06] rounded-sm overflow-hidden">
        <div 
          className="h-full rounded-sm transition-all duration-600 ease-out" 
          style={{ width: `${value}%`, background: color }}
        />
      </div>
      <span className="font-mono text-xs min-w-[28px] text-right" style={{ color }}>{value}%</span>
      {trend !== 0 && (
        <span 
          className="text-xs min-w-[24px] text-right" 
          style={{ color: trend > 0 ? "#4E9E7A" : "#E55A4E" }}
        >
          {trend > 0 ? "+" : ""}{trend}
        </span>
      )}
    </div>
  );
}

// ─── TRANSITION TIMELINE ──────────────────────────────────────────────────
function TransitionTimeline({ history }) {
  // Guard against null/undefined/non-array history
  if (!Array.isArray(history) || history.length === 0) {
    return null;
  }

  return (
    <div className="flex items-center gap-0">
      {history.map((item, i) => {
        // Safe: fallback to STABLE if state is not in config
        const cfg = STATE_CONFIG[item?.state] || STATE_CONFIG.STABLE;
        return (
          <div key={i} className="flex items-center">
            <div className="flex flex-col items-center gap-1">
              <div 
                className="w-2 h-2 rounded-full"
                style={{
                  background: i === history.length - 1 ? cfg.dot : "transparent",
                  border: `1.5px solid ${cfg.dot}`,
                }}
              />
              <span className="font-mono text-xs text-white/30 whitespace-nowrap">{item?.date || "—"}</span>
            </div>
            {i < history.length - 1 && (
              <div className="w-7 h-px bg-white/10 mx-0.5 mb-4" />
            )}
          </div>
        );
      })}
    </div>
  );
}

// ─── STATUS BADGE ─────────────────────────────────────────────────────────
function UrgencyBadge({ urgency }) {
  const map = {
    URGENT: { bg: "rgba(229,90,78,0.15)", color: "#E55A4E", border: "rgba(229,90,78,0.4)", text: "URGENT" },
    HIGH:   { bg: "rgba(229,90,78,0.1)",  color: "#E55A4E", border: "rgba(229,90,78,0.3)", text: "HIGH RISK" },
    MODERATE: { bg: "rgba(196,168,79,0.12)", color: "#C4A84F", border: "rgba(196,168,79,0.35)", text: "CHRONIC RISK" },
    WATCH:  { bg: "rgba(196,168,79,0.08)", color: "#C4A84F", border: "rgba(196,168,79,0.25)", text: "WATCH" },
    LOW:    { bg: "rgba(78,158,122,0.1)",  color: "#4E9E7A", border: "rgba(78,158,122,0.3)", text: "ON TRACK" },
  };
  const s = map[urgency] || map.LOW;
  return (
    <div 
      className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-sm"
      style={{ background: s.bg, border: `1px solid ${s.border}` }}
    >
      <div className="w-1.5 h-1.5 rounded-full" style={{ background: s.color }} />
      <span className="font-mono text-xs tracking-wider" style={{ color: s.color }}>{s.text}</span>
    </div>
  );
}

// ─── WEAKNESS SUMMARY GENERATOR ────────────────────────────────────────────
function getWeaknessSummary(concept) {
  const accuracy = concept.accuracy ?? 0;
  const attempts = concept.attempts ?? 0;
  const trend = concept.trend;
  const conceptName = concept.concept_name || concept.name || 'this concept';

  if (attempts < 5) {
    return `You've only seen this concept ${attempts} time${attempts === 1 ? '' : 's'}. More exposure is needed before Synapse can assess your understanding.`;
  }

  if (accuracy === 0) {
    return `You haven't answered any ${conceptName} questions correctly yet across ${attempts} attempts. This is a critical gap that needs immediate attention.`;
  }

  if (accuracy < 30) {
    const trendNote = trend !== null && trend < 30 ? " and your trend is getting worse, not better" : "";
    return `You're getting ${conceptName} wrong most of the time (${accuracy.toFixed(0)}% accuracy across ${attempts} attempts)${trendNote}. Focused reinforcement is needed.`;
  }

  if (accuracy < 60) {
    const trendNote = trend !== null && trend > 60 ? " — the good news is your trend is improving" : trend !== null && trend < 30 ? " — and your recent trend is declining" : "";
    return `Your understanding of ${conceptName} is inconsistent at ${accuracy.toFixed(0)}% across ${attempts} attempts${trendNote}. You know parts of it but it's not solid yet.`;
  }

  return `You're at ${accuracy.toFixed(0)}% on ${conceptName} across ${attempts} attempts. You're developing but need more consistency to reach mastery.`;
}

// ─── MAIN COMPONENT ───────────────────────────────────────────────────────
export default function PerformancePage() {
  const navigate = useNavigate();
  const [conceptSort, setConceptSort] = useState("priority");
  const { data, loading, error, status, isUpdating, refresh } = useLearningState({ sort: conceptSort });
  const { history: apiHistory, loading: historyLoading } = useLearningHistory();
  const [activeTab, setActiveTab] = useState("status");
  const [expandedConcept, setExpandedConcept] = useState(null);

  console.log("Learning state data:", data);
  console.log("Learning history data:", apiHistory);
  console.log("Status:", status, "isUpdating:", isUpdating);
  console.log("[PLANNER-DEBUG] Full learning state keys:", Object.keys(data || {}));
  console.log("[PLANNER-DEBUG] plannerContext:", data?.plannerContext);

  // Loading state (initial load only)
  if (loading && !data) {
    return (
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-center py-20">
          <div className="text-center">
            <div className="w-10 h-10 border-[3px] border-white/10 border-t-[#4E9E7A] rounded-full animate-spin mx-auto mb-4" />
            <p className="font-mono text-xs text-white/40">
              Loading learning state...
            </p>
          </div>
        </div>
      </div>
    );
  }

  // Pending state (computing in background, no previous snapshot)
  if (status === "pending" && !data) {
    return (
      <div className="max-w-7xl mx-auto">
        <div className="panel max-w-2xl mx-auto p-8">
          <div className="text-center">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#4E9E7A]/10 border border-[#4E9E7A]/25 mb-4">
              <div className="w-2 h-2 rounded-full bg-[#4E9E7A] animate-pulse" />
              <span className="font-mono text-xs text-[#4E9E7A] tracking-wider">COMPUTING</span>
            </div>
            <h2 className="text-xl font-semibold text-white mb-2">
              Computing learning state...
            </h2>
            <p className="text-sm text-white/50 leading-relaxed">
              Analyzing your recent practice sessions and historical patterns.
              This usually takes 5–15 seconds.
            </p>
          </div>
        </div>
      </div>
    );
  }

  // Error state
  if (status === "error" && !data) {
    return (
      <div className="max-w-7xl mx-auto">
        <div className="panel max-w-2xl mx-auto p-8 text-center">
          <p className="text-red-400 mb-2">Failed to load learning state</p>
          <p className="text-sm text-white/40 mb-4">{error || "Please try again."}</p>
          <button 
            onClick={refresh}
            className="px-4 py-2 rounded-lg bg-[#4E9E7A] hover:bg-[#5BAE8C] text-[#0C0C0E] font-semibold text-sm transition"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  // No data state (shouldn't happen with calibration mode, but keep as fallback)
  if (!data) {
    return (
      <div className="max-w-7xl mx-auto">
        <div className="panel p-8 text-center">
          <p className="text-muted">No learning state data available.</p>
          <p className="text-sm text-white/40 mt-2">Complete some MCQ sessions to generate insights.</p>
        </div>
      </div>
    );
  }

  const overallState = data.overall?.state || data.overall_state;
  
  // Calibration Mode (insufficient data state)
  if (overallState === "INSUFFICIENT_DATA") {
    const debugInputs = data.debug?.inputs ?? {};
    const recentTrendPoints = debugInputs.recent_trend_points ?? 0;
    const minPointsRequired = debugInputs.min_points_required ?? 5;
    const progress = minPointsRequired > 0 ? (recentTrendPoints / minPointsRequired) * 100 : 0;

    return (
      <div className="max-w-7xl mx-auto">
        <div className="panel max-w-2xl mx-auto overflow-hidden">
          {/* Header */}
          <div className="px-6 py-5 bg-[#111114]/50 border-b border-white/[0.07]">
            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded bg-[#4E9E7A]/10 border border-[#4E9E7A]/25 mb-3">
              <div className="w-1.5 h-1.5 rounded-full bg-[#4E9E7A]" />
              <span className="font-mono text-xs text-[#4E9E7A] tracking-wider">CALIBRATION MODE</span>
            </div>
            <h2 className="text-2xl font-semibold text-white mb-2">
              Learning Calibration Mode
            </h2>
            <p className="text-base text-white/60 leading-relaxed">
              We need at least <span className="font-mono text-white">{minPointsRequired}</span> distinct sessions 
              to measure your learning trajectory and detect patterns.
            </p>
          </div>

          {/* Progress Section */}
          <div className="px-6 py-5 bg-[#111114]/30">
            <div className="flex items-center justify-between mb-3">
              <span className="font-mono text-xs text-white/40 tracking-wider">CALIBRATION PROGRESS</span>
              <span className="font-mono text-sm text-white">
                {recentTrendPoints} / {minPointsRequired}
              </span>
            </div>
            
            {/* Progress Bar */}
            <div className="h-2 bg-white/[0.06] rounded-full overflow-hidden mb-4">
              <div 
                className="h-full bg-gradient-to-r from-[#4E9E7A] to-[#5BAE8C] rounded-full transition-all duration-500 ease-out"
                style={{ width: `${Math.min(progress, 100)}%` }}
              />
            </div>

            {/* Sessions Needed */}
            {recentTrendPoints < minPointsRequired && (
              <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-white/[0.03] border border-white/[0.08]">
                <span className="text-sm text-white/50">
                  {minPointsRequired - recentTrendPoints} more {minPointsRequired - recentTrendPoints === 1 ? 'session' : 'sessions'} needed
                </span>
              </div>
            )}
          </div>

          {/* CTA Section */}
          <div className="px-6 py-5 bg-[#0F1612] border-t border-[#4E9E7A]/20">
            <button 
              className="w-full px-5 py-3 rounded-lg bg-[#4E9E7A] hover:bg-[#5BAE8C] text-[#0C0C0E] font-semibold text-sm transition-all duration-200 hover:scale-[1.01] active:scale-[0.99]"
              onClick={() => {
                // TODO: Navigate to MCQ practice
                console.log("Start calibration session");
              }}
            >
              Start 10-minute calibration session
            </button>
            <p className="text-center text-xs text-white/35 mt-3">
              Complete practice sessions to unlock trajectory analysis
            </p>
          </div>
        </div>
      </div>
    );
  }
  
  // Extract snapshot metadata
  const snapshotId = data.snapshot_id || data.snapshot?.id || null;
  const generatedAt = data.generated_at || data.snapshot?.generated_at || null;
  
  // Safely extract momentum (can be object with .dot, number, or null)
  const rawMomentum = data.overall?.momentum || data.momentum;
  const momentum = typeof rawMomentum === 'object' && rawMomentum !== null 
    ? (rawMomentum.dot ?? 0) 
    : (rawMomentum ?? 0);
  
  const transitionHistory = Array.isArray(apiHistory) ? apiHistory : (data.transition || data.transition_history || []);
  const chronicRisk = data.chronic_risk;
  const daysInState = data.days_in_state || 0;
  
  const cfg = STATE_CONFIG[overallState] || STATE_CONFIG.STABLE;
  const copy = getMicrocopy(data);
  
  // Extract primary risk fields (handle both old flat structure and new structured)
  const primaryRiskConceptId = data.primary_risk?.concept_id || null;
  const primaryRiskConceptName = data.primary_risk?.concept_name || data.primary_risk_concept || "Unknown";
  const primaryRiskAccuracy = data.primary_risk?.accuracy ?? null;
  const primaryRiskAttempts = data.primary_risk?.attempts ?? null;
  const primaryRiskLevel = data.primary_risk?.risk_level ?? null;
  
  // Handle risk_reasons: can be string (legacy) or array (new)
  const primaryRiskReasons = Array.isArray(data.primary_risk?.risk_reasons)
    ? data.primary_risk.risk_reasons
    : (data.primary_risk?.risk_reasons || data.root_cause || "");
  
  // Extract primary_risk_evidence array (defensive default)
  const primaryRiskEvidenceList = Array.isArray(data.primary_risk_evidence) 
    ? data.primary_risk_evidence 
    : [];
  
  // Extract prescription fields (handle structured object)
  const prescriptionData = typeof data.prescription === 'object' && data.prescription !== null
    ? data.prescription
    : null;
  const prescriptionType = prescriptionData?.type || (typeof data.prescription === 'string' ? data.prescription : "");
  const prescriptionDuration = prescriptionData?.duration_minutes ?? null;
  const prescriptionCtaLabel = prescriptionData?.cta_label || copy.cta;
  const prescriptionTarget = prescriptionData?.target ?? null;
  
  // Extract root cause if present (structured object)
  const rootCause = data.root_cause && typeof data.root_cause === 'object' 
    ? data.root_cause 
    : null;
  
  // Defensive defaults for all arrays
  const conceptBreakdown = Array.isArray(data.concept_breakdown) ? data.concept_breakdown : [];
  const sessionAccuracy = Array.isArray(data.session_accuracy) ? data.session_accuracy : [];
  const sanitizedSessionAccuracy = sanitizeChartData(sessionAccuracy);
  const cohortPercentile = data.cohort_percentile || 0;
  
  // Handle session_efficiency shape (can be number or object)
  const sessionEfficiencyRaw = data.session_efficiency;
  const sessionEfficiency = typeof sessionEfficiencyRaw === 'object' && sessionEfficiencyRaw !== null
    ? sessionEfficiencyRaw
    : { efficiency: typeof sessionEfficiencyRaw === 'number' ? sessionEfficiencyRaw : null, total_correct: 0, total_time_ms: 0 };
  
  const efficiencyValue = typeof sessionEfficiency?.efficiency === 'number' 
    ? sessionEfficiency.efficiency 
    : null;
  
  // ─── PERFORMANCE SUMMARY INTERPRETATION ─────────────────────────────────
  const buildPerformanceSummary = () => {
    let rankText = "";
    if (cohortPercentile !== null && cohortPercentile !== 0) {
      if (cohortPercentile < 30) {
        rankText = "You are currently below most peers at your study stage.";
      } else if (cohortPercentile < 60) {
        rankText = "You are performing around the median compared to peers.";
      } else {
        rankText = "You are performing above most peers at your study stage.";
      }
    } else {
      rankText = "Peer comparison data is not yet available.";
    }

    let speedText = "";
    if (efficiencyValue !== null) {
      if (efficiencyValue < 2) {
        speedText = "Your solving speed is slow.";
      } else if (efficiencyValue < 4) {
        speedText = "Your solving speed is balanced.";
      } else {
        speedText = "You are answering quickly.";
      }
    } else {
      speedText = "Efficiency data is not yet available.";
    }

    let riskText = "";
    if (primaryRiskConceptName && primaryRiskConceptName !== "Unknown") {
      riskText = `Accuracy in ${primaryRiskConceptName} is currently unstable and limiting progress.`;
    } else {
      riskText = "No critical instability detected.";
    }

    return `${rankText} ${speedText} ${riskText}`;
  };

  const performanceSummary = buildPerformanceSummary();
  
  // ─── DYNAMIC CTA LABEL ──────────────────────────────────────────────────
  const getInterventionCtaLabel = () => {
    if (!prescriptionType) return prescriptionCtaLabel;
    
    const duration = prescriptionDuration || 15;
    
    if (prescriptionType.includes("REINFORCE_WEAKNESS") || prescriptionType.includes("REINFORCE")) {
      return `Start ${duration}-Minute Focus Session`;
    }
    if (prescriptionType.includes("MAINTAIN")) {
      return "Run Consolidation Session";
    }
    if (prescriptionType.includes("ACCELERATE")) {
      return "Advance to Challenge Set";
    }
    
    // Default fallback
    return prescriptionCtaLabel || `Start ${duration}-Min Session`;
  };
  
  const interventionCtaLabel = getInterventionCtaLabel();
  
  // Framing sentence for intervention
  const interventionFraming = primaryRiskConceptName && primaryRiskConceptName !== "Unknown"
    ? "Targeting this instability should improve your overall trajectory."
    : "This reinforcement is designed to consolidate recent gains.";
  
  // ─── RISK REASONS TRANSLATION ───────────────────────────────────────────
  const translateRiskReason = (reason) => {
    const translations = {
      LOW_ACCURACY: "Low accuracy trend",
      HIGH_VOLATILITY: "Performance fluctuating",
      RUSHED: "Frequent rushed errors",
      OVERTHINKING: "Extended solve time",
    };
    return translations[reason] || reason;
  };
  
  // ─── SEVERITY STATEMENT ─────────────────────────────────────────────────
  const getSeverityStatement = (riskLevel) => {
    const statements = {
      HIGH_RISK: {
        text: "This concept is actively limiting your performance.",
        color: "#E55A4E",
      },
      MODERATE_RISK: {
        text: "This concept shows instability and needs reinforcement.",
        color: "#C4A84F",
      },
      LOW_RISK: {
        text: "Minor inconsistency detected.",
        color: "rgba(255,255,255,0.4)",
      },
    };
    return statements[riskLevel] || { text: "", color: "rgba(255,255,255,0.4)" };
  };
  
  const severityInfo = getSeverityStatement(primaryRiskLevel);
  
  // ─── STABILITY CLASSIFICATION ───────────────────────────────────────────
  const getStabilityClassification = (accuracy) => {
    if (accuracy < 40) {
      return { label: "Unstable", color: "#E55A4E" };
    }
    if (accuracy <= 70) {
      return { label: "Developing", color: "#C4A84F" };
    }
    return { label: "Stable", color: "#4E9E7A" };
  };
  
  // ─── STATE FRAMING ──────────────────────────────────────────────────────
  const getStateFraming = (state) => {
    const framings = {
      IMPROVING: "You are in a recovery phase. Focus on stabilizing weak concepts to accelerate upward momentum.",
      DECLINING: "Your performance is currently unstable. Immediate reinforcement of high-risk concepts is recommended.",
      STABLE: "Your performance is stable. Controlled progression is appropriate.",
      INSUFFICIENT_DATA: "Not enough data yet. Complete more sessions to activate adaptive guidance.",
    };
    return framings[state] || "";
  };
  
  const stateFraming = getStateFraming(overallState);

  // Planner context — at top level of learning state response
  const plannerContext = data?.plannerContext;
  const examMode = plannerContext?.examMode ?? plannerContext?.exam_mode ?? false;
  const daysUntilExam = plannerContext?.daysUntilExam ?? plannerContext?.days_until_exam ?? null;
  const activePeriod = plannerContext?.activePeriod ?? plannerContext?.active_period ?? null;
  const upcomingFileEvents = Array.isArray(plannerContext?.upcomingFileEvents)
    ? plannerContext.upcomingFileEvents
    : Array.isArray(plannerContext?.upcoming_file_events)
    ? plannerContext.upcoming_file_events
    : [];
  const showExamBanner = examMode && daysUntilExam != null && daysUntilExam <= 14;
  const specialty = activePeriod?.specialty ?? activePeriod?.name ?? "your specialty";
  const upcomingCount = upcomingFileEvents.length;
  const showUpcomingLecturesRow = upcomingCount > 0;
  
  // Handler for prescription CTA
  const handlePrescriptionClick = () => {
    if (prescriptionTarget?.kind === "concept") {
      // If prescription is REINFORCE type, navigate to reinforcement session
      if (prescriptionType && (prescriptionType.includes("REINFORCE") || prescriptionType.includes("WEAKNESS"))) {
        const targetConceptId = prescriptionTarget.id || primaryRiskConceptId;
        if (targetConceptId) {
          navigate(`/learning/reinforce/${targetConceptId}`);
          return;
        }
      }
      
      // Otherwise, switch to concepts tab and expand
      setActiveTab("concepts");
      const targetConceptIndex = conceptBreakdown.findIndex(
        c => c.concept_id === prescriptionTarget.id || c.concept_id === primaryRiskConceptId || c.concept_name === primaryRiskConceptName
      );
      if (targetConceptIndex !== -1) {
        setExpandedConcept(targetConceptIndex);
      } else {
        setExpandedConcept(0);
      }
    } else {
      // For other kinds, show a placeholder message
      console.log("Prescription action:", prescriptionTarget);
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8">
      <style>{`
        .tab-btn {
          padding: 6px 0; border: none; background: transparent;
          font-size: 11px; letter-spacing: 0.06em;
          cursor: pointer; transition: all 0.15s; border-bottom: 1.5px solid transparent;
          color: rgba(255,255,255,0.35);
        }
        .tab-btn.active { color: #E8E8E8; border-bottom-color: #E8E8E8; }
        .tab-btn:hover:not(.active) { color: rgba(255,255,255,0.6); }

        .concept-row {
          padding: 10px 0; border-bottom: 1px solid rgba(255,255,255,0.05);
          cursor: pointer; transition: background 0.1s;
        }
        .concept-row:hover { background: rgba(255,255,255,0.02); }
        .concept-row:last-child { border-bottom: none; }

        @keyframes fadeSlide {
          from { opacity: 0; transform: translateY(6px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        .anim { animation: fadeSlide 0.3s ease both; }

        .cohort-fill {
          height: 100%;
          transition: width 0.8s ease;
        }
      `}</style>

      {/* Main Panel */}
      <div className="anim panel max-w-4xl mx-auto overflow-hidden">

        {/* BLOCK 1: Identity Header */}
        <div className="px-5 py-4 mb-px bg-[#111114]/50 border-b border-white/[0.07] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="font-mono text-xs text-white/25 tracking-[0.12em]">
              LEARNING STATUS
            </span>
            <span className="w-px h-3 bg-white/10" />
            <span className="font-mono text-xs text-white/25">
              Last computed: {getRelativeTime(generatedAt)}
            </span>
            {snapshotId && (
              <>
                <span className="w-px h-3 bg-white/10" />
                <span className="font-mono text-xs text-white/15" title={snapshotId}>
                  {snapshotId.slice(0, 8)}
                </span>
              </>
            )}
            {isUpdating && (
              <>
                <span className="w-px h-3 bg-white/10" />
                <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-[#4E9E7A]/10 border border-[#4E9E7A]/25">
                  <div className="w-1.5 h-1.5 rounded-full bg-[#4E9E7A] animate-pulse" />
                  <span className="font-mono text-xs text-[#4E9E7A] tracking-wider">UPDATING</span>
                </span>
              </>
            )}
          </div>
          <UrgencyBadge urgency={copy.urgency} />
        </div>

        {/* Active period badge */}
        {activePeriod && (
          <div className="px-5 pt-3 pb-1">
            <span
              className="font-mono text-xs inline-block"
              style={{
                color: "#4E9E7A",
                background: "rgba(78, 158, 122, 0.08)",
                border: "1px solid rgba(78, 158, 122, 0.4)",
                borderRadius: 20,
                padding: "4px 12px",
              }}
            >
              {activePeriod.name}
              {activePeriod.specialty ? ` · ${activePeriod.specialty}` : ""}
            </span>
          </div>
        )}

        {/* Exam Mode Banner */}
        {showExamBanner && (
          <div
            className="px-5 mb-4"
          >
            <div
              style={{
                background: "rgba(245, 158, 11, 0.10)",
                border: "1px solid rgba(245, 158, 11, 0.30)",
                borderRadius: 8,
                padding: "12px 16px",
              }}
            >
              <span className="text-sm text-white/90">
                ⚡ Exam in {daysUntilExam} {daysUntilExam === 1 ? "day" : "days"} — sessions prioritized for {specialty}
              </span>
            </div>
          </div>
        )}

        {/* Upcoming lectures info row */}
        {showUpcomingLecturesRow && (
          <div className="px-5 py-2">
            <span
              className="font-mono text-xs"
              style={{ color: "rgba(20, 184, 166, 0.7)" }}
            >
              📖 {upcomingCount} upcoming lecture{upcomingCount === 1 ? "" : "s"} linked to your rotation
            </span>
          </div>
        )}

        {/* BLOCK 2: State Signal */}
        <div 
          className="px-5 pt-6 pb-5 mb-px bg-[#111114]/50 border-b border-white/[0.07] border-t-2"
          style={{ borderTopColor: cfg.color }}
        >
          <div className="flex items-start justify-between gap-4 mb-3.5">
            <div className="flex-1">
              <div className="flex items-baseline gap-2.5 mb-1.5">
                <span 
                  className="font-mono text-2xl font-medium tracking-tight"
                  style={{ color: cfg.color }}
                >
                  {cfg.label}
                </span>
                {momentum !== 0 && (
                  <span 
                    className="font-mono text-xs"
                    style={{ color: momentum > 0 ? "#4E9E7A" : "#E55A4E" }}
                  >
                    {momentum > 0 ? "+" : ""}{momentum}%
                  </span>
                )}
              </div>
              <p className="m-0 text-base font-normal leading-[1.45] max-w-[380px]">
                {copy.headline} <span className="text-white/50">{copy.subline}</span>
              </p>
              {stateFraming && (
                <p className="m-0 mt-3 text-sm font-medium text-white/70 leading-relaxed max-w-[420px]">
                  {stateFraming}
                </p>
              )}
            </div>
            <div className="text-right shrink-0">
              <div className="font-mono text-xs text-white/30 mb-0.5">DAY {daysInState}</div>
              {sanitizedSessionAccuracy.length > 0 && <Sparkline data={sessionAccuracy} color={cfg.color} height={40} />}
            </div>
          </div>

          <TransitionTimeline history={transitionHistory} />
        </div>

        {/* BLOCK 3: Primary Risk */}
        <div 
          className="px-5 py-4 mb-px bg-[#111114]/50 border-b border-white/[0.07] border-l-[3px]"
          style={{ borderLeftColor: cfg.color }}
        >
          <div className="flex gap-3">
            <div className="flex-1">
              <div className="font-mono text-xs text-white/30 tracking-widest mb-1.5">PRIMARY RISK</div>
              
              {/* Concept name */}
              <div className="text-sm font-medium mb-1" style={{ color: cfg.color }}>
                {primaryRiskConceptName}
              </div>
              
              {/* Severity statement */}
              {severityInfo.text && (
                <p className="text-xs mb-2 leading-relaxed m-0" style={{ color: severityInfo.color }}>
                  {severityInfo.text}
                </p>
              )}
              
              {/* Accuracy + Attempts */}
              {primaryRiskAccuracy != null && (
                <div className="font-mono text-xs text-white/40 mb-1.5">
                  {primaryRiskAccuracy}% accuracy
                  {primaryRiskAttempts != null && ` (${primaryRiskAttempts} attempts)`}
                </div>
              )}
              
              {/* Translated risk_reasons badges */}
              {Array.isArray(primaryRiskReasons) && primaryRiskReasons.length > 0 && (
                <div className="flex flex-wrap gap-1.5 mt-1.5">
                  {primaryRiskReasons.map((reason, idx) => (
                    <span 
                      key={idx}
                      className="inline-flex items-center px-2 py-0.5 rounded text-xs bg-white/[0.04] border border-white/[0.08] text-white/50"
                    >
                      {translateRiskReason(reason)}
                    </span>
                  ))}
                </div>
              )}
              
              {/* String fallback for legacy risk_reasons */}
              {!Array.isArray(primaryRiskReasons) && primaryRiskReasons && (
                <div className="text-xs text-white/45 leading-[1.5]">{primaryRiskReasons}</div>
              )}
            </div>
            {chronicRisk && (
              <div className="shrink-0 self-start px-2 py-1 rounded-sm bg-[#C4A84F]/10 border border-[#C4A84F]/30">
                <div className="font-mono text-xs text-[#C4A84F] tracking-wider mb-0.5">CHRONIC</div>
                <div className="font-mono text-xs text-[#C4A84F]/70">RECURRING</div>
              </div>
            )}
          </div>
        </div>

        {/* BLOCK 4: Intervention Plan */}
        <div className="px-5 py-3.5 mb-px bg-[#0F1612] border-b border-[#4E9E7A]/20">
          <div className="flex items-center justify-between mb-1.5">
            <span className="font-mono text-xs text-[#4E9E7A]/60 tracking-widest font-semibold">INTERVENTION PLAN</span>
            {prescriptionDuration && (
              <span className="font-mono text-xs text-[#4E9E7A]/40">
                {prescriptionDuration} minutes
              </span>
            )}
          </div>
          
          <p className="m-0 text-sm text-[#C8DDD4] leading-[1.55]">
            {prescriptionType || "—"}
          </p>
          
          {/* Render structured target */}
          {prescriptionTarget && typeof prescriptionTarget === 'object' && (
            <div className="mt-2 font-mono text-xs text-[#4E9E7A]/70">
              {prescriptionTarget.kind === "concept" && (
                <>→ Focus concept: {primaryRiskConceptName}</>
              )}
              {prescriptionTarget.kind === "file" && (
                <>→ Review file: {prescriptionTarget.id}</>
              )}
              {prescriptionTarget.kind === "deck" && (
                <>→ Practice deck: {prescriptionTarget.id}</>
              )}
            </div>
          )}
          
          {/* Framing sentence */}
          <p className="mt-2.5 mb-0 text-xs text-[#4E9E7A]/50 leading-relaxed">
            {interventionFraming}
          </p>
          
          {interventionCtaLabel && (
            <button 
              onClick={handlePrescriptionClick}
              className="mt-3 px-3.5 py-1.5 rounded bg-[#4E9E7A]/[0.12] border border-[#4E9E7A]/[0.35] text-[#4E9E7A] font-mono text-xs cursor-pointer tracking-wide hover:bg-[#4E9E7A]/[0.18] transition-colors"
            >
              {interventionCtaLabel}
            </button>
          )}
        </div>

        {/* BLOCK 5: Tabs */}
        <div className="bg-[#111114]/50">
          {/* Tab nav */}
          <div className="flex gap-5 px-5 border-b border-white/[0.06]">
            {["status", "concepts", "session"].map(t => (
              <button 
                key={t} 
                className={`tab-btn ${activeTab === t ? "active" : ""}`} 
                onClick={() => setActiveTab(t)}
              >
                {t.toUpperCase()}
              </button>
            ))}
          </div>

          {/* Tab: STATUS */}
          {activeTab === "status" && (
            <div className="p-4 px-5">
              {/* Performance Summary */}
              <div className="mb-5 pb-4 border-b border-white/[0.06]">
                <div className="font-mono text-xs text-white/25 tracking-widest mb-2.5">
                  PERFORMANCE SUMMARY
                </div>
                <p className="text-sm text-white/60 leading-relaxed m-0">
                  {performanceSummary}
                </p>
              </div>

              {/* 3-stat row */}
              <div className="grid grid-cols-3 gap-3 mb-4">
                {/* Cohort Rank */}
                <div className="py-3">
                  <div className="font-mono text-xs text-white/25 tracking-widest mb-1.5 flex items-center gap-1.5">
                    COHORT RANK
                    <InfoTooltip content="Cohort rank compares your recent performance to students at the same study stage. 50th percentile = median." />
                  </div>
                  <div className="font-mono text-xl font-medium mb-0.5">{cohortPercentile}th</div>
                  <div className="text-xs text-white/30">
                    {cohortPercentile >= 50 
                      ? "You're above the median of your peers." 
                      : `Your performance is lower than ${100 - cohortPercentile}% of students at your stage.`}
                  </div>
                </div>

                {/* Session Efficiency */}
                <div className="py-3">
                  <div className="font-mono text-xs text-white/25 tracking-widest mb-1.5 flex items-center gap-1.5">
                    EFFICIENCY
                    <InfoTooltip content="Efficiency measures how many questions you answer correctly per minute of active solving time." />
                  </div>
                  <div className="font-mono text-xl font-medium mb-0.5">
                    {efficiencyValue !== null ? efficiencyValue.toFixed(1) : "—"}
                  </div>
                  <div className="text-xs text-white/30">
                    {efficiencyValue !== null 
                      ? (efficiencyValue < 2 
                          ? "Consider improving decision speed." 
                          : efficiencyValue > 4 
                            ? "Answering quickly. Ensure accuracy stays stable." 
                            : "Speed is balanced. Accuracy may be the limiting factor.")
                      : "Not enough data yet"}
                  </div>
                </div>

                {/* Attempts */}
                <div className="py-3">
                  <div className="font-mono text-xs text-white/25 tracking-widest mb-1.5 flex items-center gap-1.5">
                    ATTEMPTS
                    <InfoTooltip content="High-risk concepts are topics where your accuracy or trend indicates instability." />
                  </div>
                  <div className="font-mono text-xl font-medium mb-0.5">
                    {conceptBreakdown.reduce((a, c) => a + c.attempts, 0)}
                  </div>
                  <div className="text-xs text-white/30">questions across high-risk concepts</div>
                </div>
              </div>

              {/* Cohort bar */}
              <div>
                <div className="flex justify-between mb-1.5">
                  <span className="font-mono text-xs text-white/25 tracking-widest">COHORT POSITION</span>
                  <span className="font-mono text-xs text-white/25">vs. students at same study stage</span>
                </div>
                <div className="h-[5px] bg-white/[0.06] rounded-sm overflow-hidden relative">
                  <div 
                    className="cohort-fill rounded-sm" 
                    style={{ 
                      width: `${cohortPercentile}%`, 
                      background: cohortPercentile >= 60 ? "#4E9E7A" : cohortPercentile >= 40 ? "#C4A84F" : "#E55A4E"
                    }} 
                  />
                  <div className="absolute left-1/2 top-0 w-px h-full bg-white/20" />
                </div>
                <div className="flex justify-between mt-1">
                  <span className="font-mono text-xs text-white/20">0th</span>
                  <span className="font-mono text-xs text-white/20">median</span>
                  <span className="font-mono text-xs text-white/20">100th</span>
                </div>
              </div>
            </div>
          )}

          {/* Tab: CONCEPTS */}
          {activeTab === "concepts" && (
            <div className="p-3 px-5">
              {/* Sort Toggle */}
              <div className="flex items-center gap-2 mb-4">
                <button
                  onClick={() => setConceptSort("priority")}
                  className={`px-3 py-1.5 rounded-full font-mono text-xs transition ${
                    conceptSort === "priority"
                      ? "bg-[#4E9E7A] text-[#0C0C0E]"
                      : "border border-white/[0.15] text-white/50 hover:text-white/70"
                  }`}
                >
                  Priority
                </button>
                <button
                  onClick={() => setConceptSort("recent")}
                  className={`px-3 py-1.5 rounded-full font-mono text-xs transition ${
                    conceptSort === "recent"
                      ? "bg-[#4E9E7A] text-[#0C0C0E]"
                      : "border border-white/[0.15] text-white/50 hover:text-white/70"
                  }`}
                >
                  Recent
                </button>
              </div>
              
              <div className="font-mono text-xs text-white/25 mb-3 tracking-wide">
                TAP A CONCEPT TO START A REINFORCEMENT SESSION
              </div>
              {conceptBreakdown.length === 0 ? (
                <div className="text-center py-8 text-sm text-white/40">
                  No concept data available yet.
                </div>
              ) : (
                conceptBreakdown.map((concept, i) => {
                  const isPrimaryRisk = concept.concept_id === primaryRiskConceptId;
                  const stability = getStabilityClassification(concept.accuracy);
                  
                  return (
                    <div 
                      key={i} 
                      className={`concept-row ${isPrimaryRisk ? "border-l-2 pl-3 bg-[#E55A4E]/[0.03]" : ""}`}
                      style={isPrimaryRisk ? { borderLeftColor: "#E55A4E" } : {}}
                      onClick={() => setExpandedConcept(expandedConcept === i ? null : i)}
                    >
                      <div className={`flex items-center gap-2.5 ${expandedConcept === i ? "mb-2.5" : ""}`}>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1.5">
                            <span 
                              className="text-sm font-medium"
                              style={{ color: concept.accuracy < 60 ? "#E55A4E" : concept.accuracy < 75 ? "#C4A84F" : "#4E9E7A" }}
                            >
                              {concept.concept_name || concept.name}
                            </span>
                            {isPrimaryRisk && (
                              <span className="font-mono text-xs px-1.5 py-px rounded bg-[#E55A4E]/10 border border-[#E55A4E]/30 text-[#E55A4E]">
                                Primary Risk
                              </span>
                            )}
                            <span className="font-mono text-xs text-white/25 px-1.5 py-px border border-white/[0.08] rounded-sm">
                              {concept.facet}
                            </span>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="flex-1">
                              <AccuracyBar value={concept.accuracy} trend={concept.trend} />
                            </div>
                            <span 
                              className="font-mono text-xs px-1.5 py-px rounded-sm"
                              style={{ 
                                color: stability.color,
                                backgroundColor: `${stability.color}15`,
                                border: `1px solid ${stability.color}30`
                              }}
                            >
                              {stability.label}
                            </span>
                          </div>
                        </div>
                        <div className="text-right shrink-0">
                          <div className="font-mono text-xs text-white/25 mb-0.5">{concept.attempts} attempts</div>
                          <div className="text-white/15 text-xs">{expandedConcept === i ? "▲" : "▼"}</div>
                        </div>
                      </div>

                      {/* Concept expansion: weakness summary + start session */}
                      {expandedConcept === i && (
                        <div className="p-3 px-4 rounded bg-white/[0.025] border border-white/[0.06]">
                          <div className="font-mono text-xs text-white/30 mb-2 tracking-wide">WEAKNESS SUMMARY</div>
                          <p className="text-sm text-white/70 mb-4 leading-relaxed">
                            {getWeaknessSummary(concept)}
                          </p>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              navigate(`/learning/reinforce/${concept.concept_id}`);
                            }}
                            className="w-full px-4 py-2 rounded-lg bg-[#4E9E7A] hover:bg-[#5BAE8C] text-[#0C0C0E] font-semibold text-sm transition"
                          >
                            Start Session
                          </button>
                          {activePeriod && (
                            <div className="mt-3 pt-3 border-t border-white/[0.06]">
                              <span className="text-[10px] text-white/30">
                                📍 {activePeriod.name} rotation active
                              </span>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          )}

          {/* Tab: SESSION */}
          {activeTab === "session" && (
            <div className="p-4 px-5">
              <div className="font-mono text-xs text-white/25 mb-1.5 tracking-wide">
                Recent Session Accuracy (last 8 study blocks)
              </div>
              <div className="text-xs text-white/20 mb-3 leading-relaxed">
                Each bar represents one focused study session. Sessions are separated by &gt;2 hours of inactivity.
              </div>
              {sanitizedSessionAccuracy.length === 0 ? (
                <div className="text-center py-8 text-sm text-white/40">
                  No session history available yet.
                </div>
              ) : (
                <>
                  {/* Session chart */}
                  <div className="flex items-end gap-1.5 h-20 mb-2">
                    {sanitizedSessionAccuracy.map((accuracy, i) => {
                  const isLast = i === sanitizedSessionAccuracy.length - 1;
                  const barColor = accuracy >= 75 ? "#4E9E7A" : accuracy >= 60 ? "#C4A84F" : "#E55A4E";
                  return (
                    <div key={i} className="flex-1 flex flex-col items-center gap-1">
                      <span 
                        className="font-mono text-xs"
                        style={{ color: isLast ? barColor : "rgba(255,255,255,0.2)" }}
                      >
                        {Math.round(accuracy)}
                      </span>
                      <div 
                        className="w-full rounded-sm transition-all duration-400"
                        style={{ 
                          background: isLast ? barColor : "rgba(255,255,255,0.08)", 
                          height: `${(accuracy / 100) * 60}px` 
                        }} 
                      />
                    </div>
                  );
                })}
              </div>
              <div className="flex justify-between">
                <span className="font-mono text-xs text-white/20">8 sessions ago</span>
                <span className="font-mono text-xs text-white/20">current</span>
              </div>

              <div className="mt-5 pt-3 border-t border-white/[0.06]">
                <div className="font-mono text-xs text-white/25 mb-2.5 tracking-widest flex items-center gap-1.5">
                  SESSION EFFICIENCY (correct / min)
                  <InfoTooltip content="Efficiency measures how many questions you answer correctly per minute of active solving time." />
                </div>
                <div className="flex items-baseline gap-2">
                  <span className="font-mono text-3xl">
                    {efficiencyValue !== null ? efficiencyValue.toFixed(1) : "—"}
                  </span>
                  <span className="text-xs text-white/35">correct answers per minute</span>
                </div>
                {efficiencyValue !== null && (
                  <p className="mt-2 mb-0 text-xs text-white/35 leading-[1.5]">
                    {efficiencyValue < 2
                      ? "You're spending longer per question. Consider improving decision speed."
                      : efficiencyValue <= 4
                        ? "Your speed is balanced. Accuracy may be the limiting factor."
                        : "You're answering quickly. Ensure accuracy remains stable."}
                  </p>
                )}
              </div>
                </>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
