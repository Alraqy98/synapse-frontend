import { useState, useEffect } from "react";
import { supabase } from "../../lib/supabaseClient";
import api from "../../lib/api";

export default function ReinforcementSession({ sessionData, onComplete }) {
  // Compute initial state from sessionData (DB is source of truth)
  const getInitialState = () => {
    // Find first unanswered question
    const firstUnansweredIndex = sessionData.questions.findIndex(
      q => !q.user_answer
    );
    const startIndex = firstUnansweredIndex >= 0 ? firstUnansweredIndex : 0;

    // Build answers array from questions that have user_answer
    const previousAnswers = sessionData.questions
      .filter(q => q.user_answer)
      .map(q => ({
        question_id: q.id,
        selected_option_id: q.user_answer.selected_option_id,
        is_correct: q.user_answer.is_correct ?? false,
      }));

    // Check if all questions answered
    const allAnswered = sessionData.questions.every(q => q.user_answer);

    return { startIndex, previousAnswers, allAnswered };
  };

  const { startIndex, previousAnswers, allAnswered } = getInitialState();

  // Parse started_at timestamp for timer
  const startTime = sessionData.started_at 
    ? new Date(sessionData.started_at).getTime() 
    : Date.now();

  const [currentIndex, setCurrentIndex] = useState(startIndex);
  const [selectedOptionId, setSelectedOptionId] = useState(null);
  const [showFeedback, setShowFeedback] = useState(false);
  const [answers, setAnswers] = useState(previousAnswers);
  const [timeLeft, setTimeLeft] = useState(() => {
    const elapsed = Math.floor((Date.now() - startTime) / 1000);
    const remaining = sessionData.duration_minutes * 60 - elapsed;
    return Math.max(0, remaining);
  });
  const [sessionComplete, setSessionComplete] = useState(allAnswered);
  const [aiTeaching, setAiTeaching] = useState(null);
  const [loadingAiTeaching, setLoadingAiTeaching] = useState(false);
  const [outcomeData, setOutcomeData] = useState(null);
  const [loadingOutcome, setLoadingOutcome] = useState(false);

  const currentQuestion = sessionData.questions[currentIndex];
  const totalQuestions = sessionData.questions.length;
  const isLastQuestion = currentIndex === totalQuestions - 1;

  // Timer countdown based on started_at timestamp
  useEffect(() => {
    if (sessionComplete) return;

    const interval = setInterval(() => {
      const elapsed = Math.floor((Date.now() - startTime) / 1000);
      const remaining = Math.max(0, sessionData.duration_minutes * 60 - elapsed);
      
      setTimeLeft(remaining);
      
      // Only auto-complete via timer if actively in session (not on mount)
      if (remaining <= 0) {
        handleSessionComplete();
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [sessionComplete, startTime, sessionData.duration_minutes]); // eslint-disable-line react-hooks/exhaustive-deps

  // Generate AI teaching summary and fetch outcome if session was already complete on mount
  useEffect(() => {
    if (allAnswered) {
      if (!aiTeaching && !loadingAiTeaching) {
        generateAiTeachingSummary();
      }
      if (!outcomeData && !loadingOutcome) {
        fetchOutcomeData();
      }
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // Format timer MM:SS
  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const handleSubmit = async () => {
    if (!selectedOptionId) return;

    const selectedOption = currentQuestion.options.find(
      (opt) => opt.id === selectedOptionId
    );
    const isCorrect = selectedOption?.is_correct ?? false;

    // Update local state
    setShowFeedback(true);
    setAnswers((prev) => [
      ...prev,
      {
        question_id: currentQuestion.id,
        selected_option_id: selectedOptionId,
        is_correct: isCorrect,
      },
    ]);

    // Send answer to backend
    try {
      const session = await supabase.auth.getSession();
      const token = session?.data?.session?.access_token;

      await api.post(
        "/api/learning/mcq/answer",
        {
          question_id: currentQuestion.id,
          selected_option_id: selectedOptionId,
          is_correct: isCorrect,
          reinforcement_session_id: sessionData.session_id,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
    } catch (err) {
      console.error("Failed to save answer:", err);
    }
  };

  const handleNext = () => {
    if (isLastQuestion) {
      handleSessionComplete();
    } else {
      setCurrentIndex((prev) => prev + 1);
      setSelectedOptionId(null);
      setShowFeedback(false);
    }
  };

  const handleSessionComplete = async () => {
    try {
      const session = await supabase.auth.getSession();
      const token = session?.data?.session?.access_token;

      await api.patch(
        `/api/learning/reinforcement-session/${sessionData.session_id}`,
        {
          status: "completed",
          ended_at: new Date().toISOString(),
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
    } catch (err) {
      console.error("Failed to complete session:", err);
    }

    setSessionComplete(true);
    
    // Generate AI teaching summary and fetch outcome data
    generateAiTeachingSummary();
    fetchOutcomeData();
  };

  const fetchOutcomeData = async () => {
    setLoadingOutcome(true);

    try {
      const session = await supabase.auth.getSession();
      const token = session?.data?.session?.access_token;

      const response = await api.get(
        `/api/learning/reinforcement-session/${sessionData.session_id}/outcome`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (response.data?.success && response.data?.data) {
        setOutcomeData(response.data.data);
      }
    } catch (err) {
      console.error("Failed to fetch outcome data:", err);
      // Fail silently - outcome panel won't show
    } finally {
      setLoadingOutcome(false);
    }
  };

  const generateAiTeachingSummary = async () => {
    setLoadingAiTeaching(true);

    try {
      // Build question review data
      const wrongQuestions = [];
      const rightQuestions = [];

      sessionData.questions.forEach((question, index) => {
        const answer = answers.find((a) => a.question_id === question.id);
        const selectedOption = question.options.find(
          (opt) => opt.id === answer?.selected_option_id
        );
        const correctOption = question.options.find((opt) => opt.is_correct);
        const isCorrect = answer?.is_correct ?? false;

        const questionData = {
          question_id: question.id,
          question_text: question.question_text,
          concept_name: question.concept_name,
          selected_answer: selectedOption?.option_text || "Not answered",
          correct_answer: correctOption?.option_text || "Unknown",
        };

        if (isCorrect) {
          rightQuestions.push(questionData);
        } else {
          wrongQuestions.push(questionData);
        }
      });

      // Get auth token
      const session = await supabase.auth.getSession();
      const token = session?.data?.session?.access_token;

      // Call backend endpoint
      const response = await api.post(
        "/api/ai/teaching-summary",
        {
          session_id: sessionData.session_id,
          primary_concept_name: sessionData.primary_concept_name,
          questions: [
            ...rightQuestions.map(q => ({ ...q, is_correct: true })),
            ...wrongQuestions.map(q => ({ ...q, is_correct: false }))
          ],
          score: answers.filter((a) => a.is_correct).length,
          total: sessionData.questions.length,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (response.data?.success && response.data?.data) {
        setAiTeaching({
          performance_summary: response.data.data.performance_summary,
          focus_tip: response.data.data.focus_tip,
          question_teachings: response.data.data.question_teachings,
        });
      }
    } catch (err) {
      console.error("Failed to generate AI teaching summary:", err);
      // Fail silently - will use static explanations as fallback
    } finally {
      setLoadingAiTeaching(false);
    }
  };

  // Completion screen
  if (sessionComplete) {
    const correctCount = answers.filter((a) => a.is_correct).length;
    const totalAnswered = sessionData.questions.length;
    const percentage = totalAnswered > 0 ? Math.round((correctCount / totalAnswered) * 100) : 0;

    return (
      <div className="max-w-3xl mx-auto py-8">
        <div className="panel p-8">
          {/* Score Header */}
          <div className="text-center mb-8 pb-6 border-b border-white/[0.07]">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#4E9E7A]/10 border border-[#4E9E7A]/25 mb-4">
              <div className="w-2 h-2 rounded-full bg-[#4E9E7A]" />
              <span className="font-mono text-xs text-[#4E9E7A] tracking-wider">
                SESSION COMPLETE
              </span>
            </div>
            <div className="text-5xl font-bold text-white mb-2">
              {correctCount} / {totalAnswered} Correct
            </div>
            <div className="text-2xl text-[#4E9E7A] font-semibold">
              {percentage}%
            </div>
          </div>

          {/* AI Teaching Summary */}
          {loadingAiTeaching && (
            <div className="mb-8 p-6 rounded-lg border border-[#4E9E7A]/20 bg-[#111114]/30">
              <div className="flex items-center gap-3 text-sm text-white/50">
                <div className="w-4 h-4 rounded-full border-2 border-[#4E9E7A] border-t-transparent animate-spin" />
                <span>Generating personalized teaching summary...</span>
              </div>
            </div>
          )}

          {aiTeaching && (
            <div className="mb-8 p-6 rounded-lg border border-[#4E9E7A]/20 bg-[#111114]/30">
              <div className="font-mono text-xs text-[#4E9E7A]/60 mb-3 tracking-wider">
                AI TEACHING SUMMARY
              </div>
              
              {/* Performance Summary */}
              {aiTeaching.performance_summary && (
                <p className="text-sm text-white/80 leading-relaxed mb-5">
                  {aiTeaching.performance_summary}
                </p>
              )}

              {/* Focus Tip */}
              {aiTeaching.focus_tip && (
                <div className="mt-4 p-3 rounded-lg bg-[#4E9E7A]/5 border border-[#4E9E7A]/15">
                  <div className="font-mono text-xs text-[#4E9E7A]/60 mb-1 tracking-wider">
                    RECOMMENDED FOCUS
                  </div>
                  <p className="text-sm text-white/70">
                    {aiTeaching.focus_tip}
                  </p>
                </div>
              )}
            </div>
          )}

          {/* Impact Panel */}
          {loadingOutcome && (
            <div className="mb-8 p-6 rounded-lg border border-[#4E9E7A]/20 bg-[#111114]/30">
              <div className="flex items-center gap-3 text-sm text-white/50">
                <div className="w-4 h-4 rounded-full border-2 border-[#4E9E7A] border-t-transparent animate-spin" />
                <span>Loading outcome analysis...</span>
              </div>
            </div>
          )}

          {outcomeData && (() => {
            const accuracy = outcomeData.accuracy ?? 0;
            const improvementDelta = outcomeData.improvement_delta;
            const decayAfter = outcomeData.decay_after ?? 0;
            const confidenceScore = outcomeData.confidence_score ?? 0;
            const sessionsCount = outcomeData.sessions_count ?? 0;

            // Status badge logic
            let statusLabel = "INSUFFICIENT DATA";
            let statusColor = "rgba(255, 255, 255, 0.3)";
            let statusBg = "rgba(255, 255, 255, 0.05)";

            if (accuracy >= 0.8 && improvementDelta >= 0) {
              statusLabel = "REPAIRED";
              statusColor = "#4E9E7A";
              statusBg = "rgba(78, 158, 122, 0.15)";
            } else if (accuracy >= 0.5) {
              statusLabel = "PARTIALLY STABILIZED";
              statusColor = "#C4A84F";
              statusBg = "rgba(196, 168, 79, 0.15)";
            } else if (accuracy < 0.5 && sessionsCount >= 2) {
              statusLabel = "UNSTABLE";
              statusColor = "#E55A4E";
              statusBg = "rgba(229, 90, 78, 0.15)";
            }

            // Decay risk color
            const getDecayColor = (decay) => {
              if (decay < 0.3) return { color: "#4E9E7A", bg: "rgba(78, 158, 122, 0.15)" };
              if (decay <= 0.6) return { color: "#C4A84F", bg: "rgba(196, 168, 79, 0.15)" };
              return { color: "#E55A4E", bg: "rgba(229, 90, 78, 0.15)" };
            };

            // Confidence color
            const getConfidenceColor = (conf) => {
              if (conf > 0.6) return { color: "#4E9E7A", bg: "rgba(78, 158, 122, 0.15)" };
              if (conf >= 0.3) return { color: "#C4A84F", bg: "rgba(196, 168, 79, 0.15)" };
              return { color: "#E55A4E", bg: "rgba(229, 90, 78, 0.15)" };
            };

            const decayStyle = getDecayColor(decayAfter);
            const confidenceStyle = getConfidenceColor(confidenceScore);

            return (
              <div className="mb-8 p-6 rounded-lg border border-[#4E9E7A]/20 bg-[#111114]/30">
                <div className="font-mono text-xs text-[#4E9E7A]/60 mb-5 tracking-wider">
                  IMPACT ANALYSIS
                </div>

                {/* 2x2 Grid */}
                <div className="grid grid-cols-2 gap-4 mb-5">
                  {/* Accuracy */}
                  <div className="p-4 rounded-lg bg-[#0F1612] border border-white/[0.07]">
                    <div className="font-mono text-xs text-white/40 mb-2 tracking-wider">
                      ACCURACY
                    </div>
                    <div className="text-3xl font-bold text-white">
                      {Math.round(accuracy * 100)}%
                    </div>
                  </div>

                  {/* Improvement */}
                  <div className="p-4 rounded-lg bg-[#0F1612] border border-white/[0.07]">
                    <div className="font-mono text-xs text-white/40 mb-2 tracking-wider">
                      IMPROVEMENT
                    </div>
                    <div className="text-3xl font-bold text-white">
                      {improvementDelta != null 
                        ? `${improvementDelta >= 0 ? '+' : ''}${Math.round(improvementDelta * 100)}%` 
                        : '—'}
                    </div>
                  </div>

                  {/* Decay Risk */}
                  <div 
                    className="p-4 rounded-lg border"
                    style={{ backgroundColor: decayStyle.bg, borderColor: decayStyle.color + '40' }}
                  >
                    <div className="font-mono text-xs mb-2 tracking-wider"
                      style={{ color: decayStyle.color + 'aa' }}
                    >
                      DECAY RISK
                    </div>
                    <div className="text-3xl font-bold" style={{ color: decayStyle.color }}>
                      {Math.round(decayAfter * 100)}%
                    </div>
                  </div>

                  {/* Confidence */}
                  <div 
                    className="p-4 rounded-lg border"
                    style={{ backgroundColor: confidenceStyle.bg, borderColor: confidenceStyle.color + '40' }}
                  >
                    <div className="font-mono text-xs mb-2 tracking-wider"
                      style={{ color: confidenceStyle.color + 'aa' }}
                    >
                      CONFIDENCE
                    </div>
                    <div className="text-3xl font-bold" style={{ color: confidenceStyle.color }}>
                      {Math.round(confidenceScore * 100)}%
                    </div>
                  </div>
                </div>

                {/* Status Badge */}
                <div className="flex justify-center">
                  <div 
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-lg border font-mono text-sm font-semibold tracking-wider"
                    style={{
                      backgroundColor: statusBg,
                      borderColor: statusColor + '50',
                      color: statusColor,
                    }}
                  >
                    {statusLabel}
                  </div>
                </div>
              </div>
            );
          })()}

          {/* Per-Question Review */}
          <div className="space-y-6 mb-8">
            {sessionData.questions.slice(0, totalAnswered).map((question, qIndex) => {
              const answer = answers.find((a) => a.question_id === question.id);
              const selectedOption = question.options.find(
                (opt) => opt.id === answer?.selected_option_id
              );
              const correctOption = question.options.find((opt) => opt.is_correct);
              const wasCorrect = answer?.is_correct ?? false;

              // Get AI teaching explanation if available, else use static
              const aiExplanation = aiTeaching?.question_teachings?.find(
                (qt) => qt.question_id === question.id
              )?.teaching;
              const explanationText = aiExplanation || question.explanation;

              return (
                <div
                  key={question.id}
                  className="p-5 rounded-lg border border-white/[0.07] bg-[#111114]/30"
                >
                  {/* Question Number + Text */}
                  <div className="mb-4">
                    <div className="font-mono text-xs text-white/30 mb-2 tracking-wider">
                      QUESTION {qIndex + 1}
                    </div>
                    <p className="text-base text-white leading-relaxed">
                      {question.question_text}
                    </p>
                  </div>

                  {/* User's Answer */}
                  {selectedOption && (
                    <div
                      className="mb-3 p-3 rounded-lg border"
                      style={{
                        backgroundColor: wasCorrect
                          ? "rgba(78, 158, 122, 0.15)"
                          : "rgba(229, 90, 78, 0.15)",
                        borderColor: wasCorrect ? "#4E9E7A" : "#E55A4E",
                      }}
                    >
                      <div className="font-mono text-xs mb-1 tracking-wider"
                        style={{ color: wasCorrect ? "#4E9E7A" : "#E55A4E" }}
                      >
                        YOUR ANSWER {wasCorrect ? "✓" : "✗"}
                      </div>
                      <p className="text-sm" style={{ color: wasCorrect ? "#4E9E7A" : "#E55A4E" }}>
                        {selectedOption.option_text}
                      </p>
                    </div>
                  )}

                  {/* Correct Answer (if user was wrong) */}
                  {!wasCorrect && correctOption && (
                    <div
                      className="mb-3 p-3 rounded-lg border"
                      style={{
                        backgroundColor: "rgba(78, 158, 122, 0.15)",
                        borderColor: "#4E9E7A",
                      }}
                    >
                      <div className="font-mono text-xs text-[#4E9E7A] mb-1 tracking-wider">
                        CORRECT ANSWER
                      </div>
                      <p className="text-sm text-[#4E9E7A]">
                        {correctOption.option_text}
                      </p>
                    </div>
                  )}

                  {/* Explanation - AI teaching if available, else static */}
                  {explanationText && (
                    <div
                      className="p-3 rounded-lg border"
                      style={{
                        backgroundColor: "rgba(0, 0, 0, 0.2)",
                        borderColor: "rgba(255, 255, 255, 0.1)",
                      }}
                    >
                      <div className="font-mono text-xs text-white/40 mb-1 tracking-wider">
                        {aiExplanation ? "AI TEACHING" : "EXPLANATION"}
                      </div>
                      <p className="text-sm text-white/70 leading-relaxed">
                        {explanationText}
                      </p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Return Button */}
          {(() => {
            // Compute next action from outcome data
            let nextActionLabel = "Return to Learning";
            let nextActionSubtext = null;

            if (outcomeData) {
              const accuracy = outcomeData.accuracy ?? 0;
              const improvementDelta = outcomeData.improvement_delta;
              const sessionsCount = outcomeData.sessions_count ?? 0;

              if (accuracy >= 0.8 && improvementDelta >= 0) {
                nextActionLabel = "Continue to Next Concept";
                nextActionSubtext = "Great work — Synapse will surface your next priority.";
              } else if (accuracy >= 0.5) {
                nextActionLabel = "Schedule Next Session";
                nextActionSubtext = outcomeData.next_review_at
                  ? `Next review recommended: ${new Date(outcomeData.next_review_at).toLocaleDateString()}`
                  : "Come back tomorrow for your next session.";
              } else if (accuracy < 0.5 && sessionsCount >= 2) {
                nextActionLabel = "Review Source Material";
                nextActionSubtext = "Revisit your notes on this concept before retrying.";
              }
            }

            return (
              <div>
                <button
                  onClick={onComplete}
                  className="w-full px-6 py-4 rounded-lg bg-[#4E9E7A] hover:bg-[#5BAE8C] text-[#0C0C0E] font-semibold text-base transition-all duration-200 hover:scale-[1.01] active:scale-[0.99]"
                >
                  {nextActionLabel}
                </button>
                {nextActionSubtext && (
                  <p className="text-xs text-white/40 text-center mt-2">
                    {nextActionSubtext}
                  </p>
                )}
              </div>
            );
          })()}
        </div>
      </div>
    );
  }

  // Session in progress
  return (
    <div className="max-w-3xl mx-auto py-8">
      <div className="panel overflow-hidden">
        {/* Header Bar */}
        <div className="px-6 py-4 bg-[#111114]/50 border-b border-white/[0.07] flex items-center justify-between">
          {/* Left: Title + Badge */}
          <div className="flex items-center gap-3">
            <span className="text-sm font-semibold text-white">
              Reinforcement Session
            </span>
            <span className="px-2 py-1 rounded-lg bg-[#4E9E7A]/10 border border-[#4E9E7A]/25 text-xs font-mono text-[#4E9E7A]">
              {sessionData.primary_concept_name}
            </span>
          </div>

          {/* Center: Progress */}
          <div className="font-mono text-sm text-white/70">
            {currentIndex + 1} / {totalQuestions}
          </div>

          {/* Right: Timer */}
          <div
            className={`font-mono text-sm font-semibold ${
              timeLeft < 60 ? "text-[#E55A4E]" : "text-white/70"
            }`}
          >
            {formatTime(timeLeft)}
          </div>
        </div>

        {/* Question Card */}
        <div className="px-6 py-6 bg-[#111114]/30">
          {/* Question Text */}
          <div className="mb-6">
            <div className="font-mono text-xs text-white/30 mb-3 tracking-wider">
              QUESTION {currentIndex + 1}
            </div>
            <p className="text-lg text-white leading-relaxed">
              {currentQuestion.question_text}
            </p>
          </div>

          {/* Options */}
          <div className="space-y-3">
            {currentQuestion.options.map((option) => {
              const isSelected = option.id === selectedOptionId;
              const isCorrect = option.is_correct;

              let bgColor = "rgba(255, 255, 255, 0.03)";
              let borderColor = "rgba(255, 255, 255, 0.08)";
              let textColor = "var(--text-main)";

              if (showFeedback) {
                if (isCorrect) {
                  bgColor = "rgba(78, 158, 122, 0.15)";
                  borderColor = "#4E9E7A";
                  textColor = "#4E9E7A";
                } else if (isSelected) {
                  bgColor = "rgba(229, 90, 78, 0.15)";
                  borderColor = "#E55A4E";
                  textColor = "#E55A4E";
                } else {
                  textColor = "rgba(255, 255, 255, 0.3)";
                }
              } else if (isSelected) {
                bgColor = "rgba(63, 124, 255, 0.15)";
                borderColor = "#3F7CFF";
                textColor = "var(--text-main)";
              }

              return (
                <button
                  key={option.id}
                  onClick={() => {
                    if (!showFeedback) {
                      setSelectedOptionId(option.id);
                    }
                  }}
                  disabled={showFeedback}
                  className="w-full px-4 py-3 rounded-lg text-left transition-all"
                  style={{
                    backgroundColor: bgColor,
                    border: `1px solid ${borderColor}`,
                    color: textColor,
                    cursor: showFeedback ? "default" : "pointer",
                  }}
                >
                  <span className="text-sm">{option.option_text}</span>
                </button>
              );
            })}
          </div>

          {/* Explanation (after submit) */}
          {showFeedback && currentQuestion.explanation && (
            <div
              className="mt-6 p-4 rounded-lg border"
              style={{
                backgroundColor: "rgba(0, 0, 0, 0.2)",
                borderColor: "rgba(255, 255, 255, 0.1)",
              }}
            >
              <div className="font-mono text-xs text-white/40 mb-2 tracking-wider">
                EXPLANATION
              </div>
              <p className="text-sm text-white/70 leading-relaxed">
                {currentQuestion.explanation}
              </p>
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="px-6 py-5 bg-[#0F1612] border-t border-white/[0.07] flex gap-3">
          {!showFeedback ? (
            <button
              onClick={handleSubmit}
              disabled={!selectedOptionId}
              className="flex-1 px-6 py-3 rounded-lg font-semibold text-sm transition-all duration-200"
              style={{
                backgroundColor: selectedOptionId ? "#3F7CFF" : "rgba(255, 255, 255, 0.05)",
                color: selectedOptionId ? "#FFF" : "rgba(255, 255, 255, 0.3)",
                cursor: selectedOptionId ? "pointer" : "not-allowed",
              }}
            >
              Submit Answer
            </button>
          ) : (
            <button
              onClick={handleNext}
              className="flex-1 px-6 py-3 rounded-lg bg-[#4E9E7A] hover:bg-[#5BAE8C] text-[#0C0C0E] font-semibold text-sm transition-all duration-200 hover:scale-[1.01] active:scale-[0.99]"
            >
              {isLastQuestion ? "Finish" : "Next"}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
