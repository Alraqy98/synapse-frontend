import React, { useState } from 'react';
import { Mail, Lock, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import AuthInput from './AuthInput';
import { supabase } from '../../lib/supabaseClient';
import AppLogo from '../AppLogo';

const Login = ({ onSuccess, onSwitchToSignup, adminMode = false }) => {
    const navigate = useNavigate();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [failedAttempts, setFailedAttempts] = useState(0);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError(null);

        try {
            const { data, error: signInError } = await supabase.auth.signInWithPassword({
                email,
                password,
            });

            if (signInError) {
                setFailedAttempts(prev => prev + 1);
                throw signInError;
            }

            // Reset failed attempts on success
            setFailedAttempts(0);

            // Get full user data
            const { data: userData, error: userError } = await supabase.auth.getUser();

            if (userError) {
                console.error("Failed to load user metadata:", userError);
            }

            const user = userData?.user;
            const fullName = user?.user_metadata?.full_name || "";
            const emailFromUser = user?.email || "";

            // Pass metadata to parent → goes into onboardingFlow initialData
            onSuccess({
                fullName,
                email: emailFromUser,
            });

            // Redirect based on entry route
            if (adminMode) {
                // Admin login: redirect to /admin
                navigate("/admin");
            } else {
                // Normal login: redirect to /dashboard
                navigate("/dashboard");
            }

        } catch (err) {
            // Show user-friendly error message
            const errorMessage = err.message || "Invalid email or password. Please try again.";
            setError(errorMessage);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen w-full flex items-center justify-center p-6 relative overflow-hidden">
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-teal/20 blur-[120px] rounded-full pointer-events-none animate-pulse-slow" />

            <div className="w-full max-w-[420px] animate-fade-in-up relative z-10">

                <div className="panel p-8 backdrop-blur-xl bg-[#191D22]/80 border border-white/10 rounded-3xl">

                    <div className="text-center mb-10">
                        <div className="flex items-center justify-center mb-6">
                            <AppLogo size={32} />
                        </div>

                        <h1 className="text-2xl font-bold text-white mb-2">Welcome Back</h1>
                        <p className="text-sm text-muted">Log in with your email and password.</p>
                    </div>

                    <form onSubmit={handleSubmit}>
                        <AuthInput
                            label="Email Address"
                            icon={Mail}
                            value={email}
                            onChange={e => {
                                setEmail(e.target.value);
                                setError(null); // Clear error when user types
                            }}
                            required
                        />

                        <div>
                            <AuthInput
                                label="Password"
                                icon={Lock}
                                type="password"
                                value={password}
                                onChange={e => {
                                    setPassword(e.target.value);
                                    setError(null); // Clear error when user types
                                }}
                                required
                            />
                            
                            {/* Inline error message */}
                            {error && (
                                <p className="mt-2 text-sm text-red-400">
                                    {error}
                                </p>
                            )}

                            {/* Forgot password link - only show after failed attempt */}
                            {failedAttempts > 0 && (
                                <button
                                    type="button"
                                    onClick={() => navigate('/forgot-password')}
                                    className="mt-2 text-sm text-teal hover:underline"
                                >
                                    Forgot password?
                                </button>
                            )}
                        </div>

                        <button
                            type="submit"
                            disabled={loading}
                            className="w-full mt-6 bg-teal text-black font-bold py-4 rounded-xl disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                            {loading ? "Signing In..." : "Log In"}
                        </button>
                    </form>

                    {!adminMode && (
                        <div className="mt-8 pt-6 border-t border-white/5 text-center">
                            <p className="text-sm text-muted">
                                Don't have an account?{" "}
                                <button
                                    onClick={onSwitchToSignup}
                                    className="text-teal hover:underline"
                                >
                                    Sign Up
                                </button>
                            </p>
                        </div>
                    )}

                </div>
            </div>
        </div>
    );
};

export default Login;
